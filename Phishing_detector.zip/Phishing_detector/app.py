import streamlit as st
import re
import pickle
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from tensorflow.keras.models import load_model # type: ignore
import numpy as np

# Load necessary resources
nltk.download("stopwords")
ps = PorterStemmer()

# Load the models
model_cnn = load_model('CNN_MODEL_2.h5')
model_cnn_lstm = load_model(r"CNN_LSTM_MODEL_2.h5")

# Load the vectorizer
with open('tfidf_vectorizer.pkl', 'rb') as file:
    loaded_vectorizer = pickle.load(file)

def preprocess_url(url):
    """Preprocess the URL for prediction."""
    review = re.sub(r"[^a-zA-Z]", " ", url)
    review = review.lower()
    review = review.split()
    review = [ps.stem(word) for word in review if word not in set(stopwords.words("english"))]
    return " ".join(review)

def predict_url(url, model):
    """Predict if the given URL is phishing or legitimate."""
    processed_url = preprocess_url(url)
    transformed_url = loaded_vectorizer.transform([processed_url]).toarray()
    prediction = model.predict(transformed_url)
    return "Legitimate" if prediction < 0.5 else "Phishing"

# Streamlit UI
st.set_page_config(page_title="URL Phishing Detector", layout="centered")
st.title("🔍 URL Phishing Detector")
st.write("Enter a URL below to check if it's legitimate or phishing.")

# Sidebar for model selection
model_option = st.sidebar.selectbox("Choose Model", ("CNN_MODEL_2", "CNN_LSTM_MODEL_2"))

# Input box for URL
url_input = st.text_input("Enter URL:", "")

if st.button("Predict"):
    if url_input:
        if model_option == "CNN_MODEL_2":
            result = predict_url(url_input, model_cnn)
        else:
            result = predict_url(url_input, model_cnn_lstm)
        st.success(f"Prediction: **{result}**")
    else:
        st.warning("Please enter a URL.")
